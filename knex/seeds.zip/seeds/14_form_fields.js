/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.seed = async function (knex) {
  // Deletes ALL existing entries
  await knex('form_field').del()
  await knex('form_field').insert([
    {
      fieldName: 'secchi',
      displayName: 'Secchi',
      unitId: 16,
      fieldType: 'input',
      inputType: 'float',
      isEnvironmentalField: true,
    },
    {
      fieldName: 'dissolvedOxygen',
      displayName: 'Dissolved Oxygen',
      unitId: 18,
      fieldType: 'input',
      inputType: 'float',
      isEnvironmentalField: true,
    },
    {
      fieldName: 'specificConductivity',
      displayName: 'Specific Conductivity',
      unitId: 19,
      fieldType: 'input',
      inputType: 'float',
      isEnvironmentalField: true,
    },
    {
      fieldName: 'electricalConductivity',
      displayName: 'Electrical Conductivity',
      unitId: 19,
      fieldType: 'input',
      inputType: 'float',
      isEnvironmentalField: true,
    },
    {
      fieldName: 'ph',
      displayName: 'pH',
      unitId: null,
      fieldType: 'input',
      inputType: 'float',
      minThreshold: 0,
      maxThreshold: 14,
      isEnvironmentalField: true,
    },
    {
      fieldName: 'tideCode',
      displayName: 'Tide',
      unitId: null,
      fieldType: 'select',
    },
    {
      fieldName: 'flowDirection',
      displayName: 'Flow Direction',
      unitId: null,
      fieldType: 'select',
    },
    {
      fieldName: 'weatherCode',
      displayName: 'Weather',
      unitId: null,
      fieldType: 'select',
    },
    {
      fieldName: 'vegetationCode',
      displayName: 'Vegetation Code',
      unitId: null,
      fieldType: 'select',
    },
    {
      fieldName: 'conditionCode',
      displayName: 'Condition Code',
      unitId: null,
      fieldType: 'select',
    },
    {
      fieldName: 'gearStatus',
      displayName: 'Gear Status',
      unitId: null,
      fieldType: 'select',
    },
    {
      fieldName: 'substrate',
      displayName: 'Substrate',
      unitId: null,
      fieldType: 'select',
    },
    {
      fieldName: 'ysiNum',
      displayName: 'YSI #',
      unitId: null,
      fieldType: 'select',
    },
    {
      fieldName: 'ysiTurbidity',
      displayName: 'YSI Turbidity',
      unitId: null,
      fieldType: 'input',
      inputType: 'float',
    },
    {
      fieldName: 'revCounter',
      displayName: 'Rev. Counter',
      unitId: null,
      fieldType: 'input',
      inputType: 'float',
    },
    {
      fieldName: 'totalRevolutions',
      displayName: 'Total Revolutions',
      unitId: null,
      fieldType: 'input',
      inputType: 'float',
    },
    {
      fieldName: 'waterTurbidity',
      displayName: 'Turbidity',
      unitId: 25,
      fieldType: 'input',
      inputType: 'float',
      isEnvironmentalField: true,
    },
    {
      fieldName: 'debrisVolume',
      displayName: 'Debris Volume',
      unitId: 37,
      fieldType: 'input',
      inputType: 'float',
      isEnvironmentalField: true,
    },
    {
      fieldName: 'milting',
      displayName: 'Milting',
      unitId: null,
      fieldType: 'radio',
    },
    {
      fieldName: 'samplingAltered',
      displayName: 'Sampling Altered',
      unitId: null,
      fieldType: 'radio',
    },
    {
      fieldName: 'dataRecorder',
      displayName: 'Data Recorder',
      unitId: null,
      fieldType: 'select',
    },
    {
      fieldName: 'length',
      displayName: 'Length',
      unitId: 16,
      fieldType: 'input',
      inputType: 'float',
    },
    {
      fieldName: 'width',
      displayName: 'Width',
      unitId: 16,
      fieldType: 'input',
      inputType: 'float',
    },
    {
      fieldName: 'depth',
      displayName: 'Depth',
      unitId: 16,
      fieldType: 'input',
      inputType: 'float',
    },
    {
      fieldName: 'trapVisitTime',
      displayName: 'Trap Visit Time',
      unitId: null,
      fieldType: 'datetime',
    },
    {
      fieldName: 'coneSetting',
      displayName: 'Cone Setting',
      unitId: null,
      fieldType: 'radio',
    },
    {
      fieldName: 'fieldCheck',
      displayName: 'Field Check',
      unitId: null,
      fieldType: 'select',
    },
    {
      fieldName: 'sampleTime',
      displayName: 'Sample Time',
      unitId: null,
      fieldType: 'datetime',
    },
    {
      fieldName: 'coneDepth',
      displayName: 'Cone Depth',
      unitId: 11,
      fieldType: 'input',
      inputType: 'float',
      isEnvironmentalField: true,
    },
    {
      fieldName: 'secPer3Rotations',
      displayName: 'Sec. / 3 Rotations',
      fieldType: 'input',
      inputType: 'float',
      isEnvironmentalField: true,
    },
    {
      fieldName: 'trapInThalweg',
      displayName: 'Thalweg',
      fieldType: 'radio',
      isEnvironmentalField: false,
    },
    {
      fieldName: 'riverDepth',
      displayName: 'River Depth',
      unitId: 9,
      fieldType: 'input',
      inputType: 'float',
      isEnvironmentalField: true,
    },
    {
      fieldName: 'flowMeterStart',
      displayName: 'Flow Meter Start',
      fieldType: 'input',
      inputType: 'float',
      isEnvironmentalField: true,
    },
    {
      fieldName: 'flowMeterEnd',
      displayName: 'Flow Meter End',
      fieldType: 'input',
      inputType: 'float',
      isEnvironmentalField: true,
    },
    {
      fieldName: 'flowMeterTime',
      displayName: 'Flow Meter Time',
      fieldType: 'input',
      inputType: 'float',
      isEnvironmentalField: true,
      unitId: 32, // seconds
    },
    {
      fieldName: 'eggs',
      displayName: 'Eggs',
      fieldType: 'radio',
      isEnvironmentalField: false,
    },
    {
      fieldName: 'flowMeterSerialNumber',
      displayName: 'Flow Meter Serial #',
      fieldType: 'input',
      inputType: 'text',
      isEnvironmentalField: true,
    },
    {
      fieldName: 'counterStart',
      displayName: 'Counter Start',
      fieldType: 'input',
      inputType: 'float',
      isEnvironmentalField: true,
    },
    {
      fieldName: 'counterEnd',
      displayName: 'Counter End',
      fieldType: 'input',
      inputType: 'float',
      isEnvironmentalField: true,
    },
    {
      fieldName: 'waterTemperature',
      displayName: 'Water Temperature',
      fieldType: 'input',
      isEnvironmentalField: false,
      inputType: 'float',
    },
    {
      fieldName: 'startTime',
      displayName: 'Start Time',
      fieldType: 'datetime',
      isEnvironmentalField: false,
    },
    {
      fieldName: 'take',
      displayName: 'Take',
      fieldType: 'select',
      isEnvironmentalField: false,
    },
    {
      fieldName: 'condition',
      displayName: 'Condition',
      fieldType: 'select',
      isEnvironmentalField: false,
    },
    {
      fieldName: 'genetic',
      displayName: 'Genetic',
      fieldType: 'radio',
      isEnvironmentalField: false,
    },
    {
      fieldName: 'labWeight',
      displayName: 'Lab Weight',
      fieldType: 'input',
      isEnvironmentalField: false,
      inputType: 'float',
    },
  ])
  await knex('program_fields').insert([
    {
      programId: 5,
      formFieldId: 1,
      required: true,
      formSection: 'Trap Operations',
      orderIndex: 5,
      equipmentId: null,
    },
    {
      programId: 5,
      formFieldId: 2,
      required: true,
      formSection: 'Trap Operations',
      orderIndex: 6,
      equipmentId: null,
    },
    {
      programId: 5,
      formFieldId: 3,
      required: true,
      formSection: 'Trap Operations',
      orderIndex: 7,
      equipmentId: null,
    },
    {
      programId: 5,
      formFieldId: 4,
      required: true,
      formSection: 'Trap Operations',
      orderIndex: 8,
      equipmentId: null,
    },
    {
      programId: 5,
      formFieldId: 5,
      required: true,
      formSection: 'Trap Operations',
      orderIndex: 9,
      equipmentId: null,
    },
    {
      programId: 5,
      formFieldId: 7,
      required: true,
      formSection: 'Trap Operations',
      orderIndex: 3,
      equipmentId: null,
    },
    {
      programId: 5,
      formFieldId: 8,
      required: true,
      formSection: 'Trap Operations',
      orderIndex: 4,
      equipmentId: null,
    },
    {
      programId: 5,
      formFieldId: 9,
      required: true,
      formSection: 'Trap Operations',
      orderIndex: 10,
      equipmentId: null,
    },
    {
      programId: 5,
      formFieldId: 10,
      required: true,
      formSection: 'Trap Post-Processing',
      orderIndex: 3,
      equipmentId: null,
    },
    {
      programId: 5,
      formFieldId: 11,
      required: true,
      formSection: 'Trap Operations',
      orderIndex: 11,
      equipmentId: 3,
    },
    {
      programId: 5,
      formFieldId: 13,
      required: true,
      formSection: 'Trap Operations',
      orderIndex: 1,
      equipmentId: null,
    },
    {
      programId: 5,
      formFieldId: 14,
      required: true,
      formSection: 'Trap Operations',
      orderIndex: 12,
      equipmentId: null,
    },
    {
      programId: 5,
      formFieldId: 18,
      required: false,
      formSection: 'Trap Post-Processing',
      orderIndex: 1,
      equipmentId: null,
    },
    {
      programId: 5,
      formFieldId: 15,
      required: true,
      formSection: 'Trap Post-Processing',
      orderIndex: 2,
      equipmentId: 3,
    },
    {
      programId: 5,
      formFieldId: 19,
      required: true,
      formSection: 'Fish Input',
      orderIndex: 1,
      equipmentId: null,
    },
    {
      programId: 5,
      formFieldId: 6,
      required: true,
      formSection: 'Trap Post-Processing',
      orderIndex: 4,
      equipmentId: null,
    },
    {
      programId: 5,
      formFieldId: 20,
      required: true,
      formSection: 'Trap Post-Processing',
      orderIndex: 5,
      equipmentId: null,
    },
    {
      programId: 6,
      formFieldId: 20,
      required: true,
      formSection: 'Trap Post-Processing',
      orderIndex: 5,
      equipmentId: null,
    },
    {
      programId: 5,
      formFieldId: 21,
      required: true,
      formSection: 'Visit Setup',
      orderIndex: 1,
      equipmentId: null,
    },
    {
      programId: 6,
      formFieldId: 21,
      required: true,
      formSection: 'Visit Setup',
      orderIndex: 1,
      equipmentId: null,
    },
    {
      programId: 5,
      formFieldId: 12,
      required: true,
      formSection: 'Trap Operations',
      orderIndex: 11,
      equipmentId: 7,
    },
    {
      programId: 5,
      formFieldId: 22,
      required: true,
      formSection: 'Trap Operations',
      orderIndex: 12,
      equipmentId: 7,
    },
    {
      programId: 5,
      formFieldId: 23,
      required: true,
      formSection: 'Trap Operations',
      orderIndex: 13,
      equipmentId: 7,
    },
    {
      programId: 5,
      formFieldId: 24,
      required: true,
      formSection: 'Trap Operations',
      orderIndex: 14,
      equipmentId: 7,
    },
    {
      programId: 5,
      formFieldId: 11, // gear status
      required: true,
      formSection: 'Trap Operations',
      orderIndex: 11,
      equipmentId: 16, //fyke trap
    },
    {
      programId: 5,
      formFieldId: 25, // trap visit time
      required: true,
      formSection: 'Trap Operations',
      orderIndex: 0,
      equipmentId: 3, //rst
    },
    {
      programId: 5,
      formFieldId: 25, // trap visit time
      required: true,
      formSection: 'Trap Post-Processing',
      orderIndex: 0,
      equipmentId: 7, // beach seine
    },
    {
      programId: 5,
      formFieldId: 25, // trap visit time
      required: true,
      formSection: 'Trap Post-Processing',
      orderIndex: 0,
      equipmentId: 16, //fyke trap
    },
    {
      programId: 5,
      formFieldId: 27, // field check
      required: true,
      formSection: 'Incomplete Sections',
      orderIndex: 1,
      equipmentId: null, //all
    },
    {
      programId: 7,
      formFieldId: 26, // cone setting
      required: true,
      formSection: 'Trap Operations',
      orderIndex: 3,
      equipmentId: null, //all
    },
    {
      programId: 8,
      formFieldId: 26, // cone setting
      required: true,
      formSection: 'Trap Operations',
      orderIndex: 3,
      equipmentId: null, //all
    },
    {
      programId: 7,
      formFieldId: 18, // debris volume
      required: true,
      formSection: 'Trap Operations',
      orderIndex: 30,
      equipmentId: null, //all
    },
    {
      programId: 8,
      formFieldId: 18, // debris volume
      required: true,
      formSection: 'Trap Operations',
      orderIndex: 30,
      equipmentId: null, //all
    },
    {
      programId: 7,
      formFieldId: 17, // turbidity
      required: false,
      formSection: 'Trap Operations',
      orderIndex: 31,
      equipmentId: null, //all
    },
    {
      programId: 8,
      formFieldId: 17, // turbidity
      required: false,
      formSection: 'Trap Operations',
      orderIndex: 31,
      equipmentId: null, //all
    },
    {
      programId: 7,
      formFieldId: 8, // weather
      required: true,
      formSection: 'Trap Operations',
      orderIndex: 1,
      equipmentId: null, //all
    },
    {
      programId: 8,
      formFieldId: 8, // weather
      required: true,
      formSection: 'Trap Operations',
      orderIndex: 1,
      equipmentId: null, //all
    },
    {
      programId: 7,
      formFieldId: 28, // sample time
      required: true,
      formSection: 'Trap Operations',
      orderIndex: 102,
      equipmentId: null, //all
    },
    {
      programId: 8,
      formFieldId: 28, // sample time
      required: true,
      formSection: 'Trap Operations',
      orderIndex: 102,
      equipmentId: null, //all
    },
    {
      programId: 7,
      formFieldId: 29, // cone depth
      required: true,
      formSection: 'Trap Operations',
      orderIndex: 4,
      equipmentId: null, //all
    },
    {
      programId: 8,
      formFieldId: 29, // cone depth
      required: true,
      formSection: 'Trap Operations',
      orderIndex: 4,
      equipmentId: null, //all
    },
    {
      programId: 7,
      formFieldId: 30,
      required: true,
      formSection: 'Trap Operations',
      orderIndex: 5,
    },
    {
      programId: 8,
      formFieldId: 30,
      required: true,
      formSection: 'Trap Operations',
      orderIndex: 5,
    },
    {
      programId: 7,
      formFieldId: 31,
      required: true,
      formSection: 'Trap Operations',
      orderIndex: 2,
    },
    {
      programId: 8,
      formFieldId: 31,
      required: true,
      formSection: 'Trap Operations',
      orderIndex: 2,
    },
    {
      programId: 7,
      formFieldId: 32,
      required: true,
      formSection: 'Trap Operations',
      orderIndex: 6,
    },
    {
      programId: 8,
      formFieldId: 32,
      required: true,
      formSection: 'Trap Operations',
      orderIndex: 6,
    },
    {
      programId: 7,
      formFieldId: 33,
      required: true,
      formSection: 'Trap Operations',
      orderIndex: 7,
    },
    {
      programId: 8,
      formFieldId: 33,
      required: true,
      formSection: 'Trap Operations',
      orderIndex: 7,
    },
    {
      programId: 7,
      formFieldId: 34,
      required: true,
      formSection: 'Trap Operations',
      orderIndex: 8,
    },
    {
      programId: 8,
      formFieldId: 34,
      required: true,
      formSection: 'Trap Operations',
      orderIndex: 8,
    },
    {
      programId: 7,
      formFieldId: 35,
      required: true,
      formSection: 'Trap Operations',
      orderIndex: 9,
    },
    {
      programId: 8,
      formFieldId: 35,
      required: true,
      formSection: 'Trap Operations',
      orderIndex: 9,
    },
    {
      programId: 5,
      formFieldId: 36, // eggs
      required: true,
      formSection: 'Fish Input',
      orderIndex: 2,
      equipmentId: null,
    },
    {
      programId: 7,
      formFieldId: 37, // flow meter serial number
      required: false,
      formSection: 'Trap Operations',
      orderIndex: 10,
      equipmentId: null,
    },
    {
      programId: 8,
      formFieldId: 37, // flow meter serial number
      required: false,
      formSection: 'Trap Operations',
      orderIndex: 10,
      equipmentId: null,
    },
    {
      programId: 7,
      formFieldId: 38, // counter start
      required: false,
      formSection: 'Trap Operations',
      orderIndex: 11,
      equipmentId: null,
    },
    {
      programId: 8,
      formFieldId: 38, // counter start
      required: false,
      formSection: 'Trap Operations',
      orderIndex: 11,
      equipmentId: null,
    },
    {
      programId: 7,
      formFieldId: 39, // counter end
      required: false,
      formSection: 'Trap Operations',
      orderIndex: 12,
      equipmentId: null,
    },
    {
      programId: 8,
      formFieldId: 39, // counter end
      required: false,
      formSection: 'Trap Operations',
      orderIndex: 12,
      equipmentId: null,
    },
    {
      programId: 5,
      formFieldId: 40, // water temp
      required: true,
      formSection: 'Trap Operations',
      orderIndex: 0,
      equipmentId: null,
    },
    {
      programId: 6,
      formFieldId: 40, // water temp
      required: true,
      formSection: 'Trap Operations',
      orderIndex: 0,
      equipmentId: null,
    },
    {
      programId: 7,
      formFieldId: 40, // water temp
      required: false,
      formSection: 'Trap Operations',
      orderIndex: 0,
      equipmentId: null,
    },
    {
      programId: 8,
      formFieldId: 40, // water temp
      required: false,
      formSection: 'Trap Operations',
      orderIndex: 0,
      equipmentId: null,
    },
    {
      programId: 7,
      formFieldId: 41, // start time
      required: true,
      formSection: 'Trap Operations',
      orderIndex: 101,
      equipmentId: null,
    },
    {
      programId: 8,
      formFieldId: 41, // start time
      required: true,
      formSection: 'Trap Operations',
      orderIndex: 101,
      equipmentId: null,
    },

    {
      programId: 6,
      formFieldId: 42, // take
      required: true,
      formSection: 'Genetics',
      orderIndex: 1,
      equipmentId: null,
    },
    {
      programId: 6,
      formFieldId: 43, // condition
      required: true,
      formSection: 'Genetics',
      orderIndex: 2,
      equipmentId: null,
    },
    {
      programId: 6,
      formFieldId: 44, // genetic
      required: true,
      formSection: 'Genetics',
      orderIndex: 3,
      equipmentId: null,
    },
    {
      programId: 5,
      formFieldId: 42, // take
      required: true,
      formSection: 'Genetics',
      orderIndex: 1,
      equipmentId: null,
    },
    {
      programId: 5,
      formFieldId: 43, // condition
      required: true,
      formSection: 'Genetics',
      orderIndex: 2,
      equipmentId: null,
    },
    {
      programId: 5,
      formFieldId: 44, // genetic
      required: true,
      formSection: 'Genetics',
      orderIndex: 3,
      equipmentId: null,
    },
  ])
}
