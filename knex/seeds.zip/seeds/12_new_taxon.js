/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.seed = async function (knex) {
  // Deletes ALL existing entries
  await knex('taxon').insert([
    {
      commonname: 'Bay Pipefish',
      latinname: 'Syngnathus leptorhynchus',
      code: '166462',
    },
    {
      commonname: 'Chameleon Goby',
      latinname: 'Tridentiger trigonocephalus',
      code: '171912',
    },
    {
      commonname: 'Chinese Mitten Crab',
      latinname: 'Eriocheir sinensis',
      code: '99058',
    },
    {
      commonname: 'Killifish',
      latinname: 'Fundulus spp.',
      code: '553174',
    },
    {
      commonname: 'Longfin Smelt',
      latinname: 'Spirinchus thaleichthys',
      code: '162049',
    },
    {
      commonname: 'Logperch',
      latinname: 'Percina caprodes',
      code: '168472',
    },
    {
      commonname: 'Pacific Staghorn Sculpin',
      latinname: 'Leptocottus armatus',
      code: '167302',
    },
    {
      commonname: 'Rainwater Killifish',
      latinname: 'Lucania parva',
      code: '165679',
    },
    {
      commonname: 'Shimofuri Goby',
      latinname: 'Tridentiger bifasciatus',
      code: '553361',
    },
    {
      commonname: 'Siberian Prawn (Shrimp)',
      latinname: 'Palaemon modestus',
      code: '1192105',
    },
    {
      commonname: 'Mississippi Grass Shrimp',
      latinname: 'Palaemonetes kadiakensis',
      code: '1192096',
    },
    {
      commonname: 'Starry Flounder',
      latinname: 'Platichthys stellatus',
      code: '172893',
    },
    {
      commonname: 'White Croaker',
      latinname: 'Genyonemus lineatus',
      code: '169257',
    },
    {
      commonname: 'Yellowfin Goby',
      latinname: 'Acanthogobius flavimanus',
      code: '171882',
    },
  ])
}
