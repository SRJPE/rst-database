/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.seed = async function (knex) {
  await knex('taxon_abbreviation').insert([
    { taxonCode: '161980', abbreviationCode: 'Chinook', isFullName: true },
    { taxonCode: '161989', abbreviationCode: 'Steelhead', isFullName: true },
    {
      taxonCode: '168160',
      abbreviationCode: 'Bass, Largemouth',
      isFullName: true,
    },
    {
      taxonCode: '550562',
      abbreviationCode: 'Bass, Smallmouth',
      isFullName: true,
    },
    { taxonCode: '168141', abbreviationCode: 'Bluegill', isFullName: true },
    {
      taxonCode: '164043',
      abbreviationCode: 'Brown Bullhead',
      isFullName: true,
    },
    {
      taxonCode: '163565',
      abbreviationCode: 'California Roach',
      isFullName: true,
    },
    {
      taxonCode: '163368',
      abbreviationCode: 'Golden Shiner',
      isFullName: true,
    },
    { taxonCode: '163587', abbreviationCode: 'Hardhead', isFullName: true },
    {
      taxonCode: '159698',
      abbreviationCode: 'Lamprey, Pacific',
      isFullName: true,
    },
    {
      taxonCode: '622248',
      abbreviationCode: 'Lamprey, River',
      isFullName: true,
    },
    {
      taxonCode: '167234',
      abbreviationCode: 'Riffle Sculpin',
      isFullName: true,
    },
    {
      taxonCode: '163524',
      abbreviationCode: 'Sac. Pikeminnow',
      isFullName: true,
    },
    { taxonCode: '163908', abbreviationCode: 'Sac. Sucker', isFullName: true },
    {
      taxonCode: '163387',
      abbreviationCode: 'Speckled Dace',
      isFullName: true,
    },
    {
      taxonCode: '168132',
      abbreviationCode: 'Sunfish, Green',
      isFullName: true,
    },
    {
      taxonCode: '168154',
      abbreviationCode: 'Sunfish, Redear',
      isFullName: true,
    },
    { taxonCode: '553322', abbreviationCode: 'Tule Perch', isFullName: true },
    {
      taxonCode: '159697',
      abbreviationCode: 'Unknown Lamprey Amct.',
      isFullName: true,
    },
    {
      taxonCode: '163342',
      abbreviationCode: 'Unknown Minnow',
      isFullName: true,
    },
    {
      taxonCode: '159707',
      abbreviationCode: 'Western Book Lamprey',
      isFullName: true,
    },
  ])

  await knex('fish_measure_protocol').insert([
    { programId: 9, species: '161980', numberMeasured: 50 },
    { programId: 9, species: '161989', numberMeasured: 10 },
    { programId: 9, species: '168160', numberMeasured: 10 },
    { programId: 9, species: '550562', numberMeasured: 10 },
    { programId: 9, species: '168141', numberMeasured: 10 },
    { programId: 9, species: '164043', numberMeasured: 10 },
    { programId: 9, species: '163565', numberMeasured: 10 },
    { programId: 9, species: '163368', numberMeasured: 10 },
    { programId: 9, species: '163587', numberMeasured: 10 },
    { programId: 9, species: '159698', numberMeasured: 10 },
    { programId: 9, species: '622248', numberMeasured: 10 },
    { programId: 9, species: '167234', numberMeasured: 10 },
    { programId: 9, species: '163524', numberMeasured: 10 },
    { programId: 9, species: '163908', numberMeasured: 10 },
    { programId: 9, species: '163387', numberMeasured: 10 },
    { programId: 9, species: '168132', numberMeasured: 10 },
    { programId: 9, species: '168154', numberMeasured: 10 },
    { programId: 9, species: '553322', numberMeasured: 10 },
    { programId: 9, species: '159697', numberMeasured: 10 },
    { programId: 9, species: '163342', numberMeasured: 10 },
    { programId: 9, species: '159707', numberMeasured: 10 },
  ])
}
