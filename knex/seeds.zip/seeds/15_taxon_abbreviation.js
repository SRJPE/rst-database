/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.seed = async function (knex) {
  // Deletes ALL existing entries
  await knex('taxon_abbreviation').del()

  await knex('taxon_abbreviation').insert([
    { taxonCode: '161702', abbreviationCode: 'AMS' }, // American Shad
    { taxonCode: '166462', abbreviationCode: 'BPF' }, // Bay Pipefish
    { taxonCode: '168487', abbreviationCode: 'BLP' }, // Bigscale logperch
    { taxonCode: '164039', abbreviationCode: 'BKB' }, // Black Bullhead
    { taxonCode: '168167', abbreviationCode: 'BKS' }, // Black Crappie
    { taxonCode: '168141', abbreviationCode: 'BGS' }, // Bluegill
    { taxonCode: '164043', abbreviationCode: 'BRB' }, // Brown Bullhead
    { taxonCode: '159707', abbreviationCode: 'BL' }, // Western Brook Lamprey
    { taxonCode: '163565', abbreviationCode: 'CAR' }, // California Roach
    { taxonCode: '171912', abbreviationCode: 'CHG' }, // Chameleon Goby
    { taxonCode: '163998', abbreviationCode: 'CHC' }, // Channel Catfish
    { taxonCode: '161980', abbreviationCode: 'CHN' }, // Chinook Salmon
    { taxonCode: '99058', abbreviationCode: 'CMC' }, // Chinese Mitten Crab
    { taxonCode: '163344', abbreviationCode: 'C' }, // Common Carp
    { taxonCode: '162032', abbreviationCode: 'DMS' }, // Common Carp
    { taxonCode: '163517', abbreviationCode: 'FHM' }, // Fathead Minnow
    { taxonCode: '163350', abbreviationCode: 'GF' }, // Gold Fish
    { taxonCode: '168132', abbreviationCode: 'GSF' }, // Green Sunfish
    { taxonCode: '163368', abbreviationCode: 'GSN' }, // Golden Shiner
    { taxonCode: '161067', abbreviationCode: 'GST' }, // Green Sturgeon
    { taxonCode: '163587', abbreviationCode: 'HH' }, // Hardhead
    { taxonCode: '163569', abbreviationCode: 'HCH' }, // Hitch
    { taxonCode: '165993', abbreviationCode: 'MSS' }, // Mississippi (Inland) Silverside
    { taxonCode: '553174', abbreviationCode: 'KLF' }, // Killifish
    { taxonCode: '159697', abbreviationCode: 'LAM' }, // Unid juvenile lamprey (ammocete)
    { taxonCode: '159697', abbreviationCode: 'AMM' }, //  Ammocoete Lamprey
    { taxonCode: '162049', abbreviationCode: 'LFS' }, // Logfin Smelt
    { taxonCode: '168160', abbreviationCode: 'LMB' }, // Largemouth Bass
    { taxonCode: '168472', abbreviationCode: 'LP' }, // Logperch
    { taxonCode: '165878', abbreviationCode: 'MQF' }, // Western Mosquito Fish
    { taxonCode: '159698', abbreviationCode: 'PL' }, // Pacific Lamprey
    { taxonCode: '167233', abbreviationCode: 'PRS' }, // Prickly Sculpin
    { taxonCode: '168144', abbreviationCode: 'SF' }, // Pumpkinseed
    { taxonCode: '168144', abbreviationCode: 'PKN' }, // Pumpkinseed
    { taxonCode: '167302', abbreviationCode: 'PSS' }, // Pacific Staghorn Sculpin
    { taxonCode: '168154', abbreviationCode: 'RES' }, // Redear Sunfish
    { taxonCode: '163792', abbreviationCode: 'RSN' }, // Red Shiner
    { taxonCode: '168163', abbreviationCode: 'REB' }, // Redeye Bass
    { taxonCode: '167234', abbreviationCode: 'RFS' }, // Riffle Sculpin
    { taxonCode: '165679', abbreviationCode: 'RFK' }, // Rainwater Killifish
    { taxonCode: '622248', abbreviationCode: 'RL' }, // River Lamprey
    { taxonCode: '163589', abbreviationCode: 'SCB' }, // Sacramento Blackfish
    { taxonCode: '163524', abbreviationCode: 'SAPM' }, // Sacramento Pikeminnow
    { taxonCode: '163524', abbreviationCode: 'SASQ' }, // Sacramento Pikeminnow
    { taxonCode: '163908', abbreviationCode: 'SASU' }, // Sacramento Sucker
    { taxonCode: '163603', abbreviationCode: 'SPLT' }, // Sacramento Splittail
    { taxonCode: '163387', abbreviationCode: 'SPD' }, // Sacramento Speckled Dace
    { taxonCode: '550562', abbreviationCode: 'SMB' }, // Smallmouth Bass
    { taxonCode: '553361', abbreviationCode: 'SHM' }, // Shimofuri Goby
    { taxonCode: '161989', abbreviationCode: 'RBT' }, // Rainbow Trout (Steel Head)
    { taxonCode: '167680', abbreviationCode: 'STB' }, // Striped Bass
    { taxonCode: '1192096', abbreviationCode: 'SHRK' }, // Mississippi Grass Shrimp
    { taxonCode: '1192105', abbreviationCode: 'SHR' }, // Siberian Prawn (Shrimp)
    { taxonCode: '168161', abbreviationCode: 'SPB' }, // Spotted bass
    { taxonCode: '172893', abbreviationCode: 'STF' }, // Starry Flounder
    { taxonCode: '161738', abbreviationCode: 'TFS' }, // Threadfin Shad
    { taxonCode: '166365', abbreviationCode: 'TSS' }, // Threespine Stickleback
    { taxonCode: '553322', abbreviationCode: 'TP' }, // Tule Perch
    { taxonCode: '168139', abbreviationCode: 'W' }, // Warmouth
    { taxonCode: '162033', abbreviationCode: 'WAG' }, // Wakasagi
    { taxonCode: '169257', abbreviationCode: 'WCK' }, // White Croaker
    { taxonCode: '164037', abbreviationCode: 'WHC' }, // White Catfish
    { taxonCode: '168166', abbreviationCode: 'WHS' }, // White Crappie
    { taxonCode: '161068', abbreviationCode: 'WST' }, // White Sturgeon
    { taxonCode: '164041', abbreviationCode: 'YEB' }, // Yellow Bullhead
    { taxonCode: '171882', abbreviationCode: 'YFG' }, // Yellowfin Goby
    { taxonCode: '161030', abbreviationCode: 'UNID' }, // Unid Fish or Unknown bony fish
    { taxonCode: '168158', abbreviationCode: 'BAS' }, // Unid juvenile bass (Micropterus)
    { taxonCode: '163995', abbreviationCode: 'CAT' }, // Unid juvenile Ictalurid (catfish)
    { taxonCode: '163342', abbreviationCode: 'MIN' }, // Unid juvenile Minnow
    { taxonCode: '167229', abbreviationCode: 'SCP' }, // Unid juvenile Sculpin
    { taxonCode: '168130', abbreviationCode: 'SNF' }, // Unid juvenile sunfish (Lepomis)
  ])
}
