/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.seed = async function (knex) {
  // Deletes ALL existing entries

  await knex('fishProcessed').insert([
    {
      definition: 'no catch data, setting trap',
      description: 'No catch data - trap is being set',
    },
  ])

  await knex('unit').insert([
    {
      definition: 'gallons (gal)',
    },
    {
      definition: 'formazin nephelometric units (FNU)',
    },
  ])
}
