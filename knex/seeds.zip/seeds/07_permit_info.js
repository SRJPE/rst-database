/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.seed = async function (knex) {
  // Deletes ALL existing entries
  await knex('permit_info').del()
  await knex('permit_info').insert([
    {
      permitId: 26021,
      programId: 1,
      streamName: 'Mill Creek',
      permitStartDate: '2022-01-01',
      permitEndDate: '2022-12-31',
      temperatureThreshold: 16,
      frequencySamplingInclementWeather: 4,
      // permitType: '4d',
    },
    {
      permitId: 26021,
      programId: 2,
      streamName: 'Deer Creek',
      permitStartDate: '2022-01-01',
      permitEndDate: '2022-12-31',
      temperatureThreshold: 16,
      frequencySamplingInclementWeather: 4,
      // permitType: '4d',
    },
    {
      permitId: 28410,
      programId: 3,
      streamName: 'Feather River',
      permitStartDate: '2025-01-01',
      permitEndDate: '2025-12-31',
      temperatureThreshold: 21,
      // permitType: '4d',
    },
    {
      permitId: 28410,
      programId: 4,
      streamName: 'Yuba River',
      permitStartDate: '2025-01-01',
      permitEndDate: '2025-12-31',
      temperatureThreshold: 21,
      // permitType: '4d',
    },
    {
      permitId: 12345,
      programId: 6,
      streamName: 'FlowWest Test',
      permitStartDate: '2025-01-01',
      permitEndDate: '2025-12-31',
      temperatureThreshold: 21,
      // permitType: '4d',
    },
  ])
}
