/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.seed = async function (knex) {
  // Deletes ALL existing entries
  await knex('condition_code').del()
  await knex('condition_code').insert([
    { code: '1', description: 'Good (normal sample)' },
    {
      code: '2',
      description:
        'Fair (sample partially compromised; less than 50% loss in effort or catch)',
    },
    {
      code: '3',
      description:
        'Poor (sample majorly compromised; 50%+ loss in effort or catch)',
    },
    { code: '4', description: 'No sample taken 100% loss of effort/sample' },
  ])

  // Deletes ALL existing entries
  await knex('vegetation_code').del()
  await knex('vegetation_code').insert([
    { code: '1', description: 'No veg present' },
    {
      code: '2',
      description: 'Veg present but no impact to sample',
    },
    {
      code: '3',
      description: 'Veg present and impact to sample',
    },
    { code: '4', description: 'Veg present and prevented sample' },
  ])

  // Deletes ALL existing entries
  await knex('tide_code').del()
  await knex('tide_code').insert([
    { code: 'EBB', description: 'Moving from high to low' },
    {
      code: 'FLD',
      description: 'Moving from low to high',
    },
    {
      code: 'HIGH',
      description: '30 mins before or after high',
    },
    { code: 'LOW', description: '30 mins before or after low' },
    { code: 'OB', description: 'Water at site is over the bank' },
  ])

  // Deletes ALL existing entries
  await knex('flow_direction').del()
  await knex('flow_direction').insert([
    {
      code: 'Upstream',
      description: 'North (to the right if facing toe drain)',
    },
    {
      code: 'Downstream',
      description: 'South (to the left)',
    },
    {
      code: 'Neutral',
      description: `neither or can't tell`,
    },
  ])

  // Deletes ALL existing entries
  await knex('weather_code').del()
  await knex('weather_code').insert([
    {
      code: 'NIT',
      description: 'Night',
    },
    {
      code: 'FOG',
      description: 'Foggy',
    },
    {
      code: 'RAN',
      description: `Precipitation`,
    },
    {
      code: 'CLD',
      description: `Overcast or cloud cover > 50%`,
    },
    {
      code: 'CLR',
      description: `Direct sunlight`,
    },
  ])

  // Deletes ALL existing entries
  await knex('substrate').del()
  await knex('substrate').insert([
    {
      code: 'GR',
      description: 'Gravel',
    },
    {
      code: 'MD',
      description: 'Mud (Can be a boat ramp)',
    },
    {
      code: 'SN',
      description: `Sand`,
    },
    {
      code: 'PV',
      description: `Pavement (Clean boat ramp)`,
    },
    {
      code: 'VG',
      description: `Vegetation`,
    },
  ])

  // Deletes ALL existing entries
  await knex('gear_status').del()
  await knex('gear_status').insert([
    {
      code: 'S',
      description: 'Set',
    },
    {
      code: 'C',
      description: 'Check',
    },
    {
      code: 'P',
      description: `Pull`,
    },
  ])

  // Deletes ALL existing entries
  await knex('ysi_num').del()
  await knex('ysi_num').insert([
    {
      code: '1',
      description: '',
    },
    {
      code: '2',
      description: '',
    },
    {
      code: '3',
      description: ``,
    },
  ])

  // Deletes ALL existing entries
  await knex('take').del()
  await knex('take').insert([
    {
      code: 'N',
      description: 'No',
    },
    {
      code: 'I',
      description: 'Indirect (non-Intentional)',
    },
    {
      code: 'D',
      description: 'Direct (Intentional)',
    },
  ])

  // Deletes ALL existing entries
  await knex('condition').del()
  await knex('condition').insert([
    {
      code: 'G',
      description: 'Good = Clear eyes, body intact',
    },
    {
      code: 'P',
      description: 'Poor = All others',
    },
  ])
}
