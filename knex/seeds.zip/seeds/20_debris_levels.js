/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.seed = async function (knex) {
  // Deletes ALL existing entries
  await knex('debris_level').del()
  await knex('debris_level').insert([
    { code: 'light', description: 'Light' },
    { code: 'medium', description: 'Medium' },
    { code: 'heavy', description: 'Heavy' },
    { code: 'very heavy', description: 'Very Heavy' },
  ])
}
