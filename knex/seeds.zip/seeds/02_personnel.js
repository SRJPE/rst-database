/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */

const { join } = require('path')
require('dotenv').config({ path: join(__dirname, '.env') })

exports.seed = async function (knex) {
  // if (process.env.NODE_ENV === 'production') {
  //   return
  // }
  try {
    // Deletes ALL existing entries
    await knex('personnel').del()
    // seed personnel
    await knex('personnel').insert([
      {
        firstName: 'Ryan',
        lastName: 'Revnak',
        email: 'Ryan.Revnak@wildlife.ca.gov',
        agencyId: 2, // CDFWS
        role: 'lead',
        phone: '530-515-5422',
        azureUid: '2e64bd10-4a91-49d7-9403-48c76d496ec9',
      },
      {
        firstName: 'Emily',
        lastName: 'Barrier',
        agencyId: 2,
        role: 'lead',
        email: 'emily.barrier@wildlife.ca.gov',
        azureUid: 'f78ac033-1771-45b0-9723-7ec2706a09a8',
      },
      {
        firstName: 'Ross',
        lastName: 'Schaefer',
        agencyId: 2,
        role: 'non-lead',
        phone: '805-975-7120',
        email: 'Ross.Schaefer@wildlife.ca.gov',
      },
      {
        firstName: 'Matt',
        lastName: 'Johnson',
        agencyId: 2,
        role: 'non-lead',
        email: 'Matt.Johnson@wildlife.ca.gov',
      },
      {
        firstName: 'Logan',
        lastName: 'Lenniger',
        agencyId: 2,
        role: 'non-lead',
        phone: '530-966-6641',
        email: 'Logan.Lenniger@wildlife.ca.gov',
      },
      {
        firstName: 'Michaela',
        lastName: 'Leyva',
        agencyId: 8, //PSMFC
        role: 'non-lead',
        phone: '408-603-0984',
        email: 'mleyva@psmfc.org',
        azureUid: 'bb098a39-58a9-4aae-b52f-73066abf6f64',
      },
      {
        firstName: 'Brian',
        lastName: 'Krempasky',
        agencyId: 2,
        role: 'non-lead',
        phone: '215-605-6949',
        email: 'Brian.Krempasky@wildlife.ca.gov',
      },
      {
        firstName: 'Sam',
        lastName: 'Funakoshi',
        agencyId: 2,
        role: 'non-lead',
        phone: '661-644-2136',
        email: 'Sam.Funakoshi@wildlife.ca.gov',
      },
      {
        firstName: 'Kassie',
        lastName: 'Hickey',
        agencyId: 3,
        role: 'lead',
        phone: '916-799-2547',
        email: 'Kassie.Hickey@water.ca.gov',
        azureUid: '9c382cb0-564b-4402-8373-249b96414423',
      },
      {
        firstName: 'Casey',
        lastName: 'Campos',
        agencyId: 3,
        role: 'lead',
        phone: '530-624-2748',
        email: 'Casey.Campos@water.ca.gov',
        azureUid: '82e69092-469a-451f-99bd-371057bdbc3d',
      },
      {
        firstName: 'Erin',
        lastName: 'Cain',
        agencyId: 11,
        role: 'lead',
        phone: null,
        email: 'ecain@flowwest.com',
      },
      {
        firstName: 'Jordan',
        lastName: 'Hoang',
        agencyId: 11,
        role: 'lead',
        phone: null,
        email: 'jhoang@flowwest.com',
        azureUid: '19af4878-5ed9-4e47-b831-23aa2ec39cc0',
      },
      {
        firstName: 'Hunter',
        lastName: 'Herrera',
        agencyId: 11,
        role: 'lead',
        phone: null,
        email: 'hherrera@flowwest.com',
        azureUid: 'ef46d8d5-6438-434b-a70a-1131df787a5e',
      },
      {
        firstName: 'Ben',
        lastName: 'Pintel',
        agencyId: 11,
        role: 'lead',
        phone: null,
        email: 'bpintel@flowwest.com',
        azureUid: 'b523e3d3-5780-4af4-b4df-60939bc61891',
      },
      {
        firstName: 'Grace',
        lastName: 'Stieglitz',
        agencyId: 8, //PSMFC
        role: 'lead',
        email: 'gstieglitz@psmfc.org',
        azureUid: '84435dee-6df3-492c-8511-7a06d74455fe',
      },
      {
        firstName: 'Sofia',
        lastName: 'Markiewicz',
        agencyId: 8, //PSMFC
        role: 'non-lead',
        phone: '805-886-4282',
        email: 'smarkiewicz@psmfc.org',
      },
      {
        firstName: 'Emily',
        lastName: 'Barrier',
        agencyId: 8, //PSMFC
        role: 'non-lead',
        phone: '970-691-5882',
        email: 'ebarrier@psmfc.org',
      },
      {
        firstName: 'Blake',
        lastName: 'Ramaglia',
        agencyId: 8, //PSMFC
        role: 'non-lead',
        email: 'bramaglia@psmfc.org',
        azureUid: 'a95a1652-c4b7-46e7-9716-4d483f4196f6',
      },
      {
        firstName: 'Tony',
        lastName: 'Yang',
        agencyId: 8,
        role: 'non-lead',
      },
      {
        firstName: 'Mitch',
        lastName: 'Barreras',
        agencyId: 8,
        role: 'non-lead',
        email: 'mbarreras@psmfc.org',
        azureUid: '05be5ed1-f2dd-4dc0-944d-809d1cf9abf3',
      },
      {
        firstName: 'Dani',
        lastName: 'Hartwigsen',
        agencyId: 8,
        role: 'non-lead',
      },
      {
        firstName: 'Willie',
        lastName: 'Whitfield',
        agencyId: 11,
        role: 'lead',
        phone: null,
        email: 'wwhitfield@flowwest.com',
        azureUid: '39640669-43fb-43a1-b6a1-c1b434e8e344',
      },
      {
        firstName: 'Lisa',
        lastName: 'Vance',
        agencyId: 3,
        role: 'lead',
        phone: null,
        email: 'Lisa.Vance@water.ca.gov',
      },
      {
        firstName: 'JT',
        lastName: 'Casby',
        agencyId: 3,
        role: 'lead',
        phone: null,
        email: 'James.casby@water.ca.gov',
      },
      {
        firstName: 'Ashley',
        lastName: 'Vizek',
        agencyId: 11,
        role: 'lead',
        phone: null,
        email: 'avizek@flowwest.com',
        azureUid: 'abfd2115-7f57-4312-86de-ea31d3921f2d',
      },
      {
        firstName: 'Jeff',
        lastName: 'Jenkins',
        agencyId: 3,
        role: 'lead',
        phone: null,
        email: 'jeff.jenkins@water.ca.gov',
        azureUid: '8b7e4e9b-78a3-47a9-93cc-103960c3ada4',
      },
      {
        firstName: 'Marisol',
        lastName: 'Rosas',
        agencyId: 8, //PSMFC
        role: 'non-lead',
        email: 'mrosas@psmfc.org',
        azureUid: '39053830-95bf-4f4f-ade1-001744b33940',
      },
      {
        firstName: 'Ally',
        lastName: 'Stout',
        agencyId: 8, //PSMFC
        role: 'non-lead',
        email: 'astout@psmfc.org',
        azureUid: 'e7a83d4d-dde1-40cf-90b6-b3320e399899',
      },
      {
        firstName: 'Kaylee',
        lastName: 'Pebelier',
        agencyId: 8, //PSMFC
        role: 'non-lead',
        email: 'kpebelier@psmfc.org',
        azureUid: '709da74c-b79c-49b1-b80d-b0e5bcebd53f',
      },
      {
        firstName: 'Kristen',
        lastName: 'Harrison',
        agencyId: 2, // CDFWS
        role: 'non-lead',
        email: 'kristen.harrison@wildlife.ca.gov',
      },
      {
        firstName: 'Nile',
        lastName: 'Marsh',
        agencyId: 8, //PSMFC
        role: 'non-lead',
        email: 'nmarsh@psmfc.org',
      },
      {
        firstName: 'Amanda',
        lastName: 'Niemela',
        agencyId: 3,
        role: 'non-lead',
        phone: null,
        email: 'amanda.niemela@water.ca.gov',
      },
      {
        firstName: 'Francheska',
        lastName: 'Torres',
        agencyId: 3,
        role: 'non-lead',
        phone: null,
        email: 'francheska.torres@water.ca.gov',
      },
      {
        firstName: 'Crystal',
        lastName: 'Baerwaldt',
        agencyId: 3,
        role: 'non-lead',
        phone: null,
        email: 'crystal.baerwaldt@water.ca.gov',
      },
      {
        firstName: 'Anne',
        lastName: 'Boyd',
        agencyId: 3,
        role: 'non-lead',
        phone: null,
        email: 'anne.boyd@water.ca.gov',
      },
      {
        firstName: 'Mackenzie',
        lastName: 'Miner',
        agencyId: 3,
        role: 'non-lead',
        phone: null,
        email: 'mackenzie.miner@water.ca.gov',
      },
      {
        firstName: 'Jesse',
        lastName: 'Adams',
        agencyId: 3,
        role: 'non-lead',
        phone: null,
        email: 'jesse.adams@water.ca.gov',
      },
      {
        firstName: 'Adam',
        lastName: 'Shy',
        agencyId: 8,
        role: 'non-lead',
        phone: null,
        email: 'ashy@psmfc.org',
      },
      {
        firstName: 'Natasha',
        lastName: 'Wingerter',
        agencyId: 1,
        role: 'lead',
        phone: null,
        email: 'natasha_wingerter@fws.gov',
        azureUid: '54080ce9-d644-45c7-81dd-01e797be9958',
      },
      {
        firstName: 'Anna',
        lastName: 'Allison',
        agencyId: 2,
        role: 'lead',
        phone: null,
        email: 'anna.allison@wildlife.ca.gov',
        azureUid: null,
      },
      {
        firstName: 'Grant',
        lastName: 'Henley',
        agencyId: 2,
        role: 'lead',
        phone: null,
        email: 'Grantton.Henley@Wildlife.ca.gov',
        azureUid: null,
      },
    ])
  } catch (error) {
    throw error
  }
}
